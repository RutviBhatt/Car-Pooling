package com.ds.carpooling.model;

public class CarDetails {
    String modelName, carNumber, licenceNumber, licenceImg;

    public String getModelName() {
        return modelName;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public String getLicenceNumber() {
        return licenceNumber;
    }

    public String getLicenceImg() {
        return licenceImg;
    }
}
