package com.ds.carpooling.model;

public class RequestRideClass {
    String name,contact,sourceAddress,destinationAddress;

    public String getName() {
        return name;
    }

    public String getContact() {
        return contact;
    }

    public String getSourceAddress() {
        return sourceAddress;
    }

    public String getDestinationAddress() {
        return destinationAddress;
    }
}
