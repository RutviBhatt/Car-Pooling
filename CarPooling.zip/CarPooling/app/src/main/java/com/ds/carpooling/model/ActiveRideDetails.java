package com.ds.carpooling.model;

public class ActiveRideDetails {
    String sourceAdd, destinationAdd, seats, luggage;

    public String getSourceAdd() {
        return sourceAdd;
    }

    public String getDestinationAdd() {
        return destinationAdd;
    }

    public String getSeats() {
        return seats;
    }

    public String getLuggage() {
        return luggage;
    }
}
